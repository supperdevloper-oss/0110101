ImagePromptify deployment package for Hostinger

IMPORTANT: This archive has two deployment targets:

1) public_html.zip
   Static frontend only. Extract its contents directly into public_html (not into a nested folder). The .htaccess file provides SPA history-route fallback so pages such as /pricing and /image-to-prompt do not 404 on refresh, long-lived caching for fingerprinted assets, and text compression when Apache modules are enabled. /api/auth/me returns an anonymous session for this static package; other API requests return HTTP 503 until a Node backend is deployed and routed. AI generation, OAuth, payments, and feedback will not work from static files alone.

2) imagepromptify-node-app.zip
   Full React + Express project. Use this with a Hostinger Node.js application/runtime, not by copying the source files into public_html. Set the app root to the extracted project, install dependencies with npm ci, build with npm run build, then start with npm start. The Express server serves dist and /api from one origin and includes the SPA fallback.

For the Node app, configure the Hostinger environment variables from .env.example. At minimum, set SESSION_SECRET to a random value of 32+ characters. APP_URL is set to https://imagepromptify.xyz. For Google sign-in, add https://imagepromptify.xyz/api/oauth/google/callback as an authorized redirect URI in Google Cloud Console and set the matching GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET. Configure AI, Stripe, feedback, and ffmpeg/ffprobe separately if needed.

Domain and TLS setup are not included in these archives. Point imagepromptify.xyz to the Hostinger service and enable HTTPS. If Hostinger requires a separate reverse proxy between public_html and the Node app, route /api/* to the Node backend. Do not expose .env or API keys in public_html.

The external media CDN, social links, and mailto links remain unchanged as requested. See README.md and REFERENCE_AUDIT.md for service limitations and inspection notes.
